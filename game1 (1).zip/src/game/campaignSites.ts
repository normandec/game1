import type { WorldData, Rect, Zone, PoiDef, StructKind } from './world';
import type { Facility, FacilityGuard, PropKind } from './facilities';
import type { Block, Point } from './navigation';

export const GOLIATH = { x: 2800, y: 4520, w: 2360, h: 2060 };
export const MNEMOSYNE = { x: 2330, y: 2600, w: 920, h: 740 };
export const HELIOS = { x: 7300, y: 3400, w: 880, h: 780 };
export interface PatrolRoute { id: string; points: Point[]; members: string[] }
export interface LibraryVolume extends Point { number: number; read: boolean }
export interface PowerCell extends Point { id: string; kind: 'generator' | 'server'; hp: number; maxHp: number; dead: boolean }
export interface MegaCrate extends Point { id: string; label: string; loot: string; hp: number; maxHp: number; dead: boolean; w: number; h: number; color: string }
export interface CampaignSites {
  warehouse: Block; library: Block; volumes: LibraryVolume[];
  patrols: PatrolRoute[]; librarySolved: boolean; libraryProgress: number;
  helios: Block; powerCells: PowerCell[]; megaCrates: MegaCrate[];
}

interface Context {
  rects: Rect[]; zones: Zone[]; pois: PoiDef[]; facilities: Facility[]; guards: FacilityGuard[];
  gates: Point[]; vans: WorldData['vanSpots']; caches: Point[];
  lights: WorldData['spotlightSpots']; barrels: Point[];
}

export function addCampaignSites(c: Context): CampaignSites {
  const depot = { x: GOLIATH.x - GOLIATH.w / 2, y: GOLIATH.y - GOLIATH.h / 2, w: GOLIATH.w, h: GOLIATH.h };
  const archive = { x: MNEMOSYNE.x - MNEMOSYNE.w / 2, y: MNEMOSYNE.y - MNEMOSYNE.h / 2, w: MNEMOSYNE.w, h: MNEMOSYNE.h };
  const add = (x: number, y: number, w: number, h: number, kind: StructKind, height = 34, detail = false) => {
    c.rects.push({ x, y, w, h, kind, h3d: height, facilityDetail: detail });
  };
  const enclose = (b: Block, kind: StructKind, gap: number, thickness = 32) => {
    const cx = b.x + b.w / 2;
    for (const y of [b.y, b.y + b.h - thickness]) {
      add(b.x, y, (b.w - gap) / 2, thickness, kind);
      add(cx + gap / 2, y, (b.w - gap) / 2, thickness, kind);
    }
    add(b.x, b.y + thickness, thickness, b.h - thickness * 2, kind);
    add(b.x + b.w - thickness, b.y + thickness, thickness, b.h - thickness * 2, kind);
    const doors = [{ x: cx, y: b.y + thickness / 2 }, { x: cx, y: b.y + b.h - thickness / 2 }];
    c.gates.push(...doors); return doors;
  };
  const prop = (f: Facility, kind: PropKind, x: number, y: number, w: number, h: number, solid = true, color = '#b6c1b8') => {
    f.props.push({ kind, x, y, w, h, solid, color });
    if (solid) add(x, y, w, h, f.kind, 27, true);
  };
  c.zones.push({ x: depot.x - 45, y: depot.y - 45, w: depot.w + 90, h: depot.h + 90, kind: 'concrete' });
  const entrances = enclose(depot, 'curtain', 340, 36);
  c.pois.push({ id: 'goliath', kind: 'depot', x: GOLIATH.x, y: GOLIATH.y, r: 1350, name: 'GOLIATH LOGISTICS FORTRESS', sub: 'WAREHOUSING / MOTOR COLUMNS / FLIGHT CARGO', secret: false, gates: entrances });
  for (let row = 0; row < 2; row++) for (let col = 0; col < 2; col++) {
    const b = { x: depot.x + (col ? depot.w - 1235 : 85), y: depot.y + (row ? 1545 : 90), w: 1150, h: 430 };
    const number = row * 2 + col + 1;
    const doors = enclose(b, 'warehouse', 280, 27);
    const f: Facility = { ...b, id: `goliath-bay-${number}`, kind: 'warehouse', name: ['ORDNANCE RECEIVING', 'VEHICLE PARTS', 'QUANTUM FREIGHT', 'STRATEGIC RESERVES'][number - 1], code: `GL-${number}`, props: [], roofed: true, doors };
    c.facilities.push(f);
    // Mega-stock aisles: enormous containers with varied freight stacked wall to wall.
    for (let aisle = 0; aisle < 2; aisle++) for (let stack = 0; stack < 4; stack++) {
      const sx = b.x + 60 + aisle * 560 + (stack % 2) * 260, sy = b.y + 42 + Math.floor(stack / 2) * 190;
      prop(f, 'pallet', sx, sy, 244, 152, true, ['#8b5e3c', '#4b6e63', '#5c4a73', '#bd7a6a'][stack]);
      prop(f, 'pallet', sx + 28, sy + 18, 92, 216, true, ['#3d6276', '#6e5240', '#545e44', '#7a3b48'][(stack + aisle) % 4]);
      add(sx + 12, sy + 160, 60, 46, 'crate', 24);
      prop(f, 'weapons', sx + 116, sy + 164, 110, 6, false);
    }
    prop(f, 'console', b.x + b.w - 190, b.y + b.h - 74, 154, 33, false);
    c.caches.push({ x: b.x + b.w / 2 + 67, y: b.y + 103 });
    const crew = ['commander', 'warden', 'breacher', 'gunner', 'medic', 'guard', 'sapper', 'pathfinder', 'grunt', 'flamer'];
    crew.forEach((type, i) => c.guards.push({
      x: b.x + b.w / 2 + (i % 2 ? 66 : -66), y: b.y + 76 + Math.floor(i / 2) * 73,
      type, facilityId: f.id, role: i === 0 ? 'leader' : i === 4 ? 'support' : i % 3 === 0 ? 'flank' : 'screen', patrol: [],
    }));
  }
  // Neat vehicle ranks and two unobstructed central cargo lanes.
  for (let row = 0; row < 2; row++) for (let col = 0; col < 8; col++) {
    c.vans.push({ x: depot.x + 160 + col * 250, y: depot.y + 625 + row * 305, ang: Math.PI / 2 });
  }
  c.zones.push({ x: GOLIATH.x - 110, y: depot.y + depot.h, w: 220, h: 480, kind: 'road' });
  for (const x of [depot.x + 40, depot.x + depot.w - 40]) for (const y of [depot.y + 35, depot.y + depot.h - 35]) {
    c.lights.push({ x, y, speed: 0.53, sweep: 1.05 });
  }
  for (let i = 0; i < 14; i++) c.barrels.push({ x: depot.x + 72 + i % 2 * 51, y: depot.y + 705 + i * 39 });
  // Elevated gantry platforms with stock stacked on top in the central aisles.
  for (let plat = 0; plat < 3; plat++) {
    const px = depot.x + 380 + plat * 430, py = depot.y + 730 + (plat % 2) * 310;
    add(px, py, 330, 26, 'warehouse', 46);
    add(px + 42, py - 136, 240, 130, 'crate', 30);
  }

  // Giant Experimental Crates of custom choice stocked in Goliath's bays!
  const megaCrates: MegaCrate[] = [
    { id: 'tesseract', label: 'TESSERACT ENERGY CORE', loot: 'tesseract', hp: 95, maxHp: 95, dead: false, w: 92, h: 72, color: '#68e7d7', x: depot.x + 360, y: depot.y + 430 },
    { id: 'thumper', label: 'M79 HEAVY THUMPER & CLUSTERS', loot: 'gl', hp: 85, maxHp: 85, dead: false, w: 90, h: 70, color: '#f5c978', x: depot.x + depot.w - 360, y: depot.y + 430 },
    { id: 'sniper', label: 'MK-14 DMR & AP ROUNDS', loot: 'dmr', hp: 85, maxHp: 85, dead: false, w: 90, h: 70, color: '#b8a4ff', x: depot.x + 360, y: depot.y + depot.h - 430 },
    { id: 'aegis', label: 'AEGIS MATRIX POD (x3 CELLS)', loot: 'aegis_matrix', hp: 85, maxHp: 85, dead: false, w: 92, h: 72, color: '#80d9ff', x: depot.x + depot.w - 360, y: depot.y + depot.h - 430 },
    { id: 'nano', label: 'S.H.I.E.L.D. NANO-STIM (+100 HP)', loot: 'nanomed', hp: 75, maxHp: 75, dead: false, w: 86, h: 68, color: '#7dffa1', x: GOLIATH.x, y: GOLIATH.y - 120 },
    { id: 'arsenal', label: 'HYDRA WEAPONS CACHE (ROCKETS)', loot: 'rocket', hp: 90, maxHp: 90, dead: false, w: 96, h: 74, color: '#ff8a5c', x: GOLIATH.x, y: GOLIATH.y + 120 },
  ];
  megaCrates.forEach(mc => add(mc.x - mc.w / 2, mc.y - mc.h / 2, mc.w, mc.h, 'crate', 38));

  // HELIOS ERCOT: the sector's power station. 6 Generators + 4 Server Blocks! Kill them -> grid dies!
  const grid = { x: HELIOS.x - HELIOS.w / 2, y: HELIOS.y - HELIOS.h / 2, w: HELIOS.w, h: HELIOS.h };
  c.zones.push({ x: grid.x - 40, y: grid.y - 40, w: grid.w + 80, h: grid.h + 80, kind: 'concrete' });
  const gridDoors = enclose(grid, 'power', 260, 34);
  const heliosFacility: Facility = { ...grid, id: 'helios', code: 'PWR-X', kind: 'power', name: 'HELIOS POWER COMPLEX', props: [], roofed: false, doors: gridDoors };
  c.facilities.push(heliosFacility);
  c.pois.push({ id: 'helios', kind: 'depot', x: HELIOS.x, y: HELIOS.y, r: 760, name: 'HELIOS POWER COMPLEX', sub: '6 GENERATORS / 4 SERVER RACKS / SHUT DOWN GRID', secret: false, gates: gridDoors });
  const powerCells: PowerCell[] = [];
  const genSpots: [number, number][] = [
    [-290, -240], [0, -240], [290, -240],
    [-290, 140], [0, 140], [290, 140],
  ];
  genSpots.forEach(([gx, gy], i) => {
    const x = HELIOS.x + gx - 72, y = HELIOS.y + gy - 100;
    add(x, y, 144, 200, 'power', 58);
    heliosFacility.props.push({ kind: 'transformer', x, y, w: 144, h: 200, solid: true, color: '#e3ac73' });
    powerCells.push({ x: x + 72, y: y + 100, id: `gen-${i}`, kind: 'generator', hp: 260, maxHp: 260, dead: false });
    c.barrels.push({ x: x - 35, y: y + 160 }, { x: x + 165, y: y + 150 });
  });
  const serverOffsets: [number, number][] = [
    [-150, -50], [150, -50],
    [-150, 45], [150, 45],
  ];
  serverOffsets.forEach(([sx, sy], srv) => {
    const x = HELIOS.x + sx - 85, y = HELIOS.y + sy - 38;
    add(x, y, 170, 76, 'radar', 44);
    heliosFacility.props.push({ kind: 'dish', x, y, w: 170, h: 76, solid: true, color: '#aabcea' });
    powerCells.push({ x: x + 85, y: y + 38, id: `srv-${srv}`, kind: 'server', hp: 190, maxHp: 190, dead: false });
  });
  ['commander', 'warden', 'sapper', 'gunner', 'guard', 'medic', 'sentinel', 'grunt', 'flamer', 'pathfinder', 'warden', 'breacher'].forEach((type, i) => c.guards.push({
    x: HELIOS.x - 360 + i * 65, y: grid.y + grid.h - 112,
    type, facilityId: 'helios', role: i === 0 ? 'leader' : i === 11 ? 'patrol' : i % 2 ? 'screen' : 'flank',
    patrol: i === 11 ? [{ x: grid.x - 90, y: grid.y + grid.h + 90 }, { x: grid.x + grid.w + 90, y: grid.y + grid.h + 90 }] : [],
  }));
  c.lights.push(
    { x: grid.x + 40, y: grid.y + 40, speed: 0.62, sweep: 1.2 },
    { x: grid.x + grid.w - 40, y: grid.y + grid.h - 40, speed: 0.55, sweep: 1.05 },
  );

  // Mnemosyne: a deliberately quiet, pre-digital archive hidden off the main route.
  c.zones.push({ x: archive.x - 35, y: archive.y - 35, w: archive.w + 70, h: archive.h + 95, kind: 'plaza' });
  const libraryDoors = enclose(archive, 'library', 210, 32);
  const library: Facility = { ...archive, id: 'mnemosyne', code: 'SSR-0', kind: 'library', name: 'MNEMOSYNE LIBRARY', props: [], roofed: true, doors: libraryDoors };
  c.facilities.push(library);
  c.pois.push({ id: 'mnemosyne', kind: 'library', x: MNEMOSYNE.x, y: MNEMOSYNE.y, r: 550, name: 'MNEMOSYNE LIBRARY', sub: 'THE LAST WATCH / THE FIRST OATH / THE SECOND DAWN', secret: true, gates: libraryDoors });
  for (const side of [0, 1]) for (let i = 0; i < 4; i++) {
    prop(library, 'books', archive.x + (side ? archive.w - 300 : 70), archive.y + 70 + i * 147, 224, 67, true, '#bba079');
  }
  prop(library, 'table', MNEMOSYNE.x - 74, MNEMOSYNE.y - 70, 148, 110, true, '#d6b982');
  const volumes: LibraryVolume[] = [
    { x: MNEMOSYNE.x - 143, y: MNEMOSYNE.y - 206, number: 1, read: false },
    { x: MNEMOSYNE.x + 143, y: MNEMOSYNE.y + 202, number: 2, read: false },
    { x: MNEMOSYNE.x + 143, y: MNEMOSYNE.y - 206, number: 3, read: false },
  ];
  ['sentinel', 'pathfinder', 'guard', 'warden', 'guard', 'medic'].forEach((type, i) => c.guards.push({
    x: MNEMOSYNE.x + (i % 2 ? 94 : -94), y: archive.y + 155 + Math.floor(i / 2) * 203,
    type, facilityId: 'mnemosyne', role: i === 0 ? 'leader' : i === 5 ? 'support' : 'sentry', patrol: [],
  }));
  c.caches.push({ x: MNEMOSYNE.x - 80, y: archive.y + archive.h - 92 });
  return {
    warehouse: depot, library: archive, volumes, librarySolved: false, libraryProgress: 0,
    helios: grid, powerCells, megaCrates,
    patrols: [
      { id: 'goliath-patrol', points: [{ x: depot.x + 120, y: depot.y + 550 }, { x: depot.x + depot.w - 120, y: depot.y + 550 }, { x: depot.x + depot.w - 120, y: depot.y + 1065 }, { x: depot.x + 120, y: depot.y + 1065 }], members: ['commander', 'warden', 'grunt', 'grunt', 'gunner', 'pathfinder', 'grunt', 'medic'] },
      { id: 'goliath-gate', points: [{ x: GOLIATH.x - 460, y: depot.y + depot.h - 90 }, { x: GOLIATH.x + 470, y: depot.y + depot.h - 90 }], members: ['warden', 'breacher', 'grunt', 'grunt', 'gunner', 'guard', 'pathfinder', 'medic'] },
      { id: 'goliath-aisle-a', points: [{ x: depot.x + 240, y: depot.y + 820 }, { x: depot.x + depot.w - 240, y: depot.y + 820 }], members: ['grunt', 'grunt', 'gunner', 'grunt', 'grunt', 'gunner', 'grunt', 'grunt', 'gunner', 'grunt'] },
      { id: 'goliath-aisle-b', points: [{ x: depot.x + 240, y: depot.y + 1380 }, { x: depot.x + depot.w - 240, y: depot.y + 1380 }], members: ['guard', 'guard', 'grunt', 'grunt', 'grunt', 'grunt', 'guard', 'guard', 'grunt', 'grunt'] },
      { id: 'helios-wire', points: [{ x: HELIOS.x - 360, y: HELIOS.y - 330 }, { x: HELIOS.x + 360, y: HELIOS.y - 330 }, { x: HELIOS.x + 360, y: HELIOS.y + 330 }, { x: HELIOS.x - 360, y: HELIOS.y + 330 }], members: ['sapper', 'grunt', 'gunner', 'grunt', 'guard', 'grunt', 'flamer', 'grunt'] },
      { id: 'helios-column', points: [{ x: HELIOS.x, y: grid.y - 140 }, { x: HELIOS.x, y: grid.y + grid.h + 140 }], members: ['warden', 'grunt', 'grunt', 'grunt', 'grunt', 'grunt', 'grunt', 'grunt', 'grunt', 'grunt', 'grunt', 'medic'] },
      { id: 'road-watch-a', points: [{ x: 5200, y: 5400 }, { x: 6800, y: 5400 }, { x: 6800, y: 6400 }], members: ['sentinel', 'pathfinder', 'grunt', 'grunt', 'grunt', 'grunt', 'pathfinder', 'medic'] },
      { id: 'road-watch-b', points: [{ x: 4200, y: 3000 }, { x: 5400, y: 3000 }, { x: 5400, y: 4200 }], members: ['commander', 'warden', 'grunt', 'grunt', 'gunner', 'grunt', 'breacher', 'guard'] },
      { id: 'kraken-column-a', points: [{ x: 9200, y: 3600 }, { x: 10400, y: 3600 }, { x: 10400, y: 4100 }, { x: 9200, y: 4100 }], members: ['commander', 'warden', 'grunt', 'grunt', 'gunner', 'gunner', 'grunt', 'medic'] },
      { id: 'kraken-column-b', points: [{ x: 9200, y: 4800 }, { x: 10400, y: 4800 }, { x: 10400, y: 5300 }, { x: 9200, y: 5300 }], members: ['warden', 'breacher', 'grunt', 'grunt', 'flamer', 'flamer', 'grunt', 'medic'] },
    ],
  };
}